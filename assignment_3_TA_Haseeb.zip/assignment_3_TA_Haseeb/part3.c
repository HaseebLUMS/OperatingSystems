#include <stdio.h>
#include <semaphore.h>
#include "part3.h"
#include "main.h"


/*
	- DO NOT USE SLEEP FUNCTION
	- Define every helper function in .h file
	- Use Semaphores for synchronization purposes
 */

void initializeP3() {
}

/**
 * If there is a car going from SOUTH to NORTH, from lane LEFT,
 * print 
 * SOUTH NORTH LEFT
 * Also, if two cars can simulateneously travel in the two lanes,
 * first print all the cars in the LEFT lane, followed by all the
 * cars in the right lane
 */
void * goingFromToP3(void *argu){
}

void startP3(){
}